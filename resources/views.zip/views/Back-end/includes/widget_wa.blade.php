<i class="whatsapp-btn">WhatsApp</i>
<div id="whatsapp">
	<input class="tujuan" type="hidden" value="08122851379"> <!-- No. WhatsApp -->
	<label>
		<input class="nama" type="text" placeholder="Nama Lengkap..">
	</label>
	<label>
		<textarea class="pesan" placeholder="Pesan.."></textarea>
	</label>
	<a class="submit">Kirim</a>
</div>