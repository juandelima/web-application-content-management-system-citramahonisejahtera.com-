<script src="{{asset('js/jquery.js')}}"></script>
<!-- Imported styles on this page -->
  <link rel="stylesheet" href="{{asset('admin/js/jvectormap/jquery-jvectormap-1.2.2.css')}}">
  <link rel="stylesheet" href="{{asset('admin/js/rickshaw/rickshaw.min.css')}}">

  <link rel="stylesheet" href="{{asset('admin/js/datatables/datatables.css')}}">
  <link rel="stylesheet" href="{{asset('admin/js/select2/select2-bootstrap.css')}}">
  <link rel="stylesheet" href="{{asset('admin/js/select2/select2.css')}}">
  

  <!-- Bottom scripts (common) -->
  <script src="{{asset('admin/js/gsap/TweenMax.min.js')}}"></script>
  <script src="{{asset('admin/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js')}}"></script>
  <script src="{{asset('admin/js/bootstrap.js')}}"></script>
  <script src="{{asset('admin/js/joinable.js')}}"></script>
  <script src="{{asset('admin/js/resizeable.js')}}"></script>
  <script src="{{asset('admin/js/neon-api.js')}}"></script>
  <script src="{{asset('admin/js/jvectormap/jquery-jvectormap-1.2.2.min.js')}}"></script>


  <!-- Imported scripts on this page -->
  <script src="{{asset('admin/js/jvectormap/jquery-jvectormap-europe-merc-en.js')}}"></script>
  <script src="{{asset('admin/js/jvectormap/jquery-jvectormap-world-mill-en.js')}}"></script>
  <script src="{{asset('admin/js/jquery.sparkline.min.js')}}"></script>
  <script src="{{asset('admin/js/rickshaw/vendor/d3.v3.js')}}"></script>
  <script src="{{asset('admin/js/rickshaw/rickshaw.min.js')}}"></script>
  <script src="{{asset('admin/js/neon-chat.js')}}"></script>

  <script src="{{asset('admin/js/datatables/datatables.js')}}"></script>
  <script src="{{asset('admin/js/select2/select2.min.js')}}"></script>
  <script src="{{asset('admin/js/neon-chat.js')}}"></script>


  <!-- JavaScripts initializations and stuff -->
  <script src="{{asset('admin/js/neon-custom.js')}}"></script>


  <!-- Demo Settings -->
  <script src="{{asset('admin/js/neon-demo.js')}}"></script>