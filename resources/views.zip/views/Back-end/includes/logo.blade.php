<!-- logo -->
<div class="logo">
	<a href="#">
		<img src="{{asset('images/CMS_LOGO.png')}}" width="100" height="100" alt="" />
	</a>
</div>

<!-- logo collapse icon -->
<div class="sidebar-collapse">
	<a href="#" class="sidebar-collapse-icon">
		<i class="entypo-menu"></i>
	</a>
</div>


<div class="sidebar-mobile-menu visible-xs">
	<a href="#" class="with-animation">
		<i class="entypo-menu"></i>
	</a>
</div>