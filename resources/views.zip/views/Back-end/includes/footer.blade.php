<!-- Footer -->
<footer class="main">
	&copy; 2018 <strong>Pt.Citra Mahoni Sejahtera</strong>
</footer>