@extends('Back-end/template')
@section('title','About')
@section('main')
<div class="main-content">
  <h1 style="background: #ccc;">About</h1>
</div>
@endsection