@extends('Back-end/template')
@section('title','Projects')
@section('main')
<div class="main-content">
  <h1 style="background: #ccc;">Projects</h1>
</div>
@endsection