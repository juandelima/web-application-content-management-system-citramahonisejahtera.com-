@extends('Back-end/template')
@section('title','Home')
@section('main')
<h1>hello</h1>
@endsection