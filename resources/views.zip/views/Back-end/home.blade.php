@extends('Back-end/template')
@section('title','Home')
@section('main')
<div class="main-content">
  <h1 style="background: #ccc;">Hello</h1>
</div>
@endsection