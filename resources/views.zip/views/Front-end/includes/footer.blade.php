<footer>
  <div class="container top-footer">
    <div class="col-md-4 col-sm-6 bor-foot" style="margin-top: 100;">
      <h3><strong>ABOUT US</strong></h3>
      <div class="border-footer"></div>
      <br/>
      <ul class="list-footer">
        <li><a href="{{route('about')}}">Who We Are</a></li>
        <li><a href="{{route('products')}}">Request Catalog</a></li>
        <li><a href="https://api.whatsapp.com/send?phone=6282111478893&text&source&data&fbclid=IwAR2_DEe5-A3397rR1GdYoJgj0X9olAKeFeE6Xe9FZzO7crtEjaoTu3BjTBA" target="__blank">View Online Catalog</a></li>
      </ul>
    </div>

    <div class="col-md-4 col-sm-6 bor-foot" style="margin-top: 100;">
      <h3><strong>CONTACT</strong></h3>
      <div class="border-footer"></div>
      <br/>
      <ul class="list-footer">
        <li class="entypo-phone"> +62 82 111 478 893</li>
        <li class="entypo-phone"> +62 82 111 478 893</li>
        <li class="entypo-direction"> Jl. MekarJaya III / 16 Sepatan Kaw. Industri MekarJaya<br/>
        Cadas – Tangerang 15520<br/>
        BANTEN - INDONESIA</li>
      </ul>
    </div>

    <div class="col-md-4 col-sm-6" style="margin-top: 100;">
      <h3 style="color: #c06f54;"><strong>SUBSCRIBE</strong></h3>

      <div class="border-footer"></div>
      <br/>
      <form action="#" class="form-inline">
        <div class="form-group">
          <input type="email" placeholder="Your Email">  
        </div>
        <div class="form-group">
        <button type="submit" class="btn btn-default">Subscribe</button>  
        </div>
        
      </form>
    </div>
  </div>
</footer>

  <div class="container-fluid" style="color: #ccc;">
    <center>
      <img src="{{asset('images/CMS_LOGO.png')}}" style="width: 100px; height= 100px;">
      <p><span class="fa fa-copyright"></span> 2018 Copyright PT. CMS. All Rights reserved. Terms and Conditions.</p>
    </center>
  </div>