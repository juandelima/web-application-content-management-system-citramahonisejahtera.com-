<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pt. Citra Mahoni Sejahtera - @yield('title')</title>
<!-- Styles -->
<link rel="stylesheet" href="{{asset('css/style31.css')}}">
<link rel="shortcut icon" type="image/x-icon" href="{{asset('images/CMS_LOGO.png')}}" />
<link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="stylesheet" href="{{asset('css/aos.css')}}">
<link rel="stylesheet" href="{{asset('admin/css/font-icons/entypo/css/entypo.css')}}">
<link rel="stylesheet" href="{{asset('css/flickity.css')}}">
<link rel="stylesheet" href="{{asset('css/whatsApp.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/styles_uq.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/lightslider.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/jquery-ui.css')}}">
<link rel="stylesheet" type="text/css" href="https://github.com/rajnesh0409/jQuery-SimpleLens/blob/master/css/jquery.simpleGallery.css">
<link rel="stylesheet" type="text/css" href="https://github.com/rajnesh0409/jQuery-SimpleLens/blob/master/css/jquery.simpleLens.css">
<link href="https://fonts.googleapis.com/css?family=Cinzel" rel="stylesheet">
<meta name="robots" content="noindex,follow" />